use strict;
use warnings;
package DZT;
{
  $DZT::VERSION = '1.2.3';
}
# ABSTRACT: my DZT abstract
1;

__END__
=pod

=head1 NAME

DZT - my DZT abstract

=head1 VERSION

version 1.2.3

=head1 AUTHOR

Martin Senger <martin.senger@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2012 by Martin Senger.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

